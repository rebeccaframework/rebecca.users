
import string
print(string)
