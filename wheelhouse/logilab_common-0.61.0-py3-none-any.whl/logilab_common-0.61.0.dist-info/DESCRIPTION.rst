Logilab's common library
========================

What's this ?
-------------

This package contains some modules used by differents Logilab's projects.

It is released under the GNU Lesser General Public License.

There is no documentation available yet but the source code should be clean and
well documented.

Designed to ease:

* handling command line options and configuration files
* writing interactive command line tools
* manipulation of files and character strings
* manipulation of common structures such as graph, tree, and pattern such as visitor
* generating text and HTML reports
* accessing some external libraries such as OmniORB_, Pyro_...
* more...


Installation
------------

Extract the tarball, jump into the created directory and run ::

	python setup.py install

For installation options, see ::

	python setup.py install --help


Provided modules
----------------

Here is a brief description of the available modules.

Modules providing high-level features
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* `cache`, a cache implementation with a least recently used algorithm.

* `changelog`, a tiny library to manipulate our simplified ChangeLog file format.

* `clcommands`, high-level classes to define command line programs handling
  different subcommands. It is based on `configuration` to get easy command line
  / configuration file handling.

* `cli`, a base class for interactive programs using the command line.

* `configuration`, some classes to handle unified configuration from both
  command line (using optparse) and configuration file (using ConfigParser).

* `dbf`, read Visual Fox Pro DBF files.

* `proc`, interface to Linux /proc.

* `umessage`, unicode email support.

* `ureports`, micro-reports, a way to create simple reports using python objects
  without care of the final formatting. ReST and html formatters are provided.


Modules providing low-level functions and structures
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* `compat`, provides a transparent compatibility layer between different python
  versions.

* `date`, a set of date manipulation functions.

* `daemon`, a daemon function and mix-in class to properly start an Unix daemon
  process.

* `decorators`, function decorators such as cached, timed...

* `deprecation`, decorator, metaclass & all to mark functions / classes as
  deprecated or moved

* `fileutils`, some file / file path manipulation utilities.

* `graph`, graph manipulations functions such as cycle detection, bases for dot
  file generation.

* `modutils`, python module manipulation functions.

* `shellutils`, some powerful shell like functions to replace shell scripts with
  python scripts.

* `tasksqueue`, a prioritized tasks queue implementation.

* `textutils`, some text manipulation functions (ansi colorization, line wrapping,
  rest support...).

* `tree`, base class to represent tree structure, and some others to make it
  works with the visitor implementation (see below).

* `visitor`, a generic visitor pattern implementation.


Modules extending some standard modules
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* `debugger`,  `pdb` customization.

* `logging_ext`, extensions to `logging` module such as a colorized formatter
  and an easier initialization function.

* `optik_ext`, defines some new option types (regexp, csv, color, date, etc.)
  for `optik` / `optparse`

* `xmlrpcutils`, auth support for XML-RPC


Modules extending some external modules
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* `corbautils`, useful functions for use with the OmniORB_ CORBA library.

* `hg`, some Mercurial_ utility functions.

* `pyro_ext`, some Pyro_ utility functions.

* `sphinx_ext`, Sphinx_ plugin defining a `autodocstring` directive.

* `vcgutils` , utilities functions to generate file readable with Georg Sander's
  vcg tool (Visualization of Compiler Graphs).


To be deprecated modules
~~~~~~~~~~~~~~~~~~~~~~~~

Those `logilab.common` modules will much probably be deprecated in future
versions:

* `testlib`: use `unittest2`_ instead
* `pytest`: use `discover`_ instead
* `interface`: use `zope.interface`_ if you really want this
* `table`, `xmlutils`: is that used?
* `sphinxutils`: we won't go that way imo (i == syt)


Deprecated modules
~~~~~~~~~~~~~~~~~~

Those `logilab.common` modules are only there for backward compatibility. They
can go away at anytime.

* `optparser`: use `clcommands` instead

* `adbh`, `db`, `sqlgen`: see `logilab.database`_ instead

* `contexts`: content move to `shellutils`

* `html`: deprecated without replacement


Comments, support, bug reports
------------------------------

Project page http://www.logilab.org/project/logilab-common

Use the python-projects@lists.logilab.org mailing list. Since we do not have
publicly available bug tracker yet, bug reports should be emailed
there too.

You can subscribe to this mailing list at
http://lists.logilab.org/mailman/listinfo/python-projects

Archives are available at
http://lists.logilab.org/pipermail/python-projects/


.. _Pyro: http://pyro.sourceforge.net/
.. _OmniORB: http://omniorb.sourceforge.net/
.. _Mercurial: http://mercurial.selenic.com
.. _Sphinx: http://sphinx.pocoo.org/
.. _`logilab.database`: http://www.logilab.org/project/logilab-database/
.. _`unittest2`: http://pypi.python.org/pypi/unittest2
.. _`discover`: http://pypi.python.org/pypi/discover
.. _`zope.interface`: http://pypi.python.org/pypi/zope.interface


