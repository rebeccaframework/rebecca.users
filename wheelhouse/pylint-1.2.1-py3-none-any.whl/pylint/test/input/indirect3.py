from .indirect2 import AbstractToto

class ConcreteToto(AbstractToto):
    def machin(self):
        return self.helper()*2
