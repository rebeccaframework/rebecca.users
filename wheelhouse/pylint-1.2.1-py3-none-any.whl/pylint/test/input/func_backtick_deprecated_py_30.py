"""W0333: flag backtick as deprecated"""

__revision__ = None
print(repr(1))
