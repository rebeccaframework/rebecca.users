"""This is gramatically correct, but it's still a SyntaxError"""
__revision__ = None
yield 1

LAMBDA_WITH_YIELD = lambda: (yield)
