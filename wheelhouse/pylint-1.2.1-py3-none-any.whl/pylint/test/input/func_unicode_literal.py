"""Unicode literals in Python 2.*"""


__revision__ = 0

BAD_STRING = b'\u1234'
GOOD_STRING = '\u1234'
