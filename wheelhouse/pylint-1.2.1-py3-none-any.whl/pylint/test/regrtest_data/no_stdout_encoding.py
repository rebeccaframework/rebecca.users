#-*-coding:iso-8859-1-*-
class test:
    def __init__ (self, dir):
        testString = "répertoire :\n%s !"%dir

