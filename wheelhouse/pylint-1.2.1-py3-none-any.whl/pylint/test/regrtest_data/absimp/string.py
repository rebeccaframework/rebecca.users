"""
http://www.logilab.org/ticket/70495
http://www.logilab.org/ticket/70565
"""

import string
print(string)
