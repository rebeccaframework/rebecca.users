translationstring
=================

A library used by various `Pylons Project <http://pylonsproject.org>`_
packages for internationalization (i18n) duties related to translation.

This package provides a *translation string* class, a *translation
string factory* class, translation and pluralization primitives, and a
utility that helps `Chameleon <http://chameleon.repoze.org>`_
templates use translation facilities of this package.  It does not
depend on `Babel <http://babel.edgewall.org>`_, but its translation
and pluralization services are meant to work best when provided with
an instance of the ``babel.support.Translations`` class.

Please see http://docs.pylonsproject.org/projects/translationstring/dev/ or
the ``docs/index.rst`` file in this package for the documentation.


translationstring
=================

1.1 (2012-02-08)
----------------

- Add MANIFEST to make sure all files are present in a release. This fixes
  `ticket 8 <https://github.com/Pylons/translationstring/issues/8>`_.


1.0 (2012-02-04)
----------------

- coerce non-string values to a string during translation, except for None.

- Honour mapping information passed to the translator, combining it with
  mapping data already part of the translation string.

- Support formatting of translation strings with %-operator.

0.4 (09-22-2011)
----------------

- Python 3 compatibility (thanks to Joe Dallago, GSOC student).

- Remove testing dependency on Babel.

- Moved to GitHub (https://github.com/Pylons/translationstring).

- Added tox.ini for testing purposes.

0.3 (06-25-2010)
----------------

- Preserve default translations even if they are an empty string. This
  fixes problems with Chameleon being unable to determine if a translation
  is present or not.

0.2 (04-25-2010)
----------------

- Add ``__getstate__`` and ``__reduce__`` methods to translation
  string to allow for pickling.

- Fix bug in ChameleonTranslate.  When ``i18n:translate`` was used in
  templates, a translation string was inappropriately created with a
  ``default`` value of the empty string.  Symptom: template text would
  "disappear" rather than being returned untranslated.

0.1 (04-24-2010)
----------------

- Initial release.


